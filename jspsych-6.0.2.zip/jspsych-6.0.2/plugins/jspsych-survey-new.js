/**
 * jspsych-survey-new
 * a jspsych plugin for free response survey questions
 *
 * Josh de Leeuw
 *
 * documentation: docs.jspsych.org
 
 CHANGES MADE:
 Simplified the plugin.
 Only creates one text box to respond to.
 Columns is no longer required to enter.
 
 Still to do: Collect RT for when people start typing.
 
 *
 */


jsPsych.plugins['survey-new'] = (function() {

  var plugin = {};

  plugin.info = {
    name: 'survey-new',
    description: '',
    parameters: {
	  disp: {
		type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Display',
		default: "",
		description: 'The string displayed directly above the text box.'
	  },
	  value: {
		type: jsPsych.plugins.parameterType.STRING,
		pretty_name: 'Value',
		default: "",
		description: 'The string will be used to populate the response field with editable answer.'
	  },
	  rows: {
		type: jsPsych.plugins.parameterType.INT,
		pretty_name: 'Rows',
		default: 1,
		description: 'The number of rows for the response text box.'
	  },
	  columns: {
		type: jsPsych.plugins.parameterType.INT,
		pretty_name: 'Columns',
		default: 20,
		description: 'The number of columns for the response text box.'
	  },	  
      preamble: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Preamble',
        default: null,
        description: 'HTML formatted string to display at the top of the page above all the questions.'
      },
      button_label: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Button label',
        default:  'Continue',
        description: 'The text that appears on the button to finish the trial.'
      }
    }
  }

  plugin.trial = function(display_element, trial) {

	/*
	if (typeof trial.rows == 'undefined') {
		trial.rows = 1;
		console.log(trial.rows);
	}
    if (typeof trial.questions[i].columns == 'undefined') {
        trial.questions[i].columns = 40;
    }
    if (typeof trial.questions[i].value == 'undefined') {
        trial.questions[i].value = "";
    }
	*/
	
    var html = '';
    // show preamble text
    if(trial.preamble !== null){
      html += '<div id="jspsych-survey-new-preamble" class="jspsych-survey-new-preamble">'+trial.preamble+'</div>';
    }
    // add questions
	
	html += '<div id="jspsych-survey-new" class="jspsych-survey-new-question" style="margin: 2em 0em;">';
	html += '<p class="jspsych-survey-new">' + trial.disp + '</p>';
	html += '<input type="text" id="jspsych-survey-new-response" size="'+
		trial.columns+'" value="'+trial.value+'"></input>';
	html += '</div>';


    // add submit button
    html += '<button id="jspsych-survey-new-next" class="jspsych-btn jspsych-survey-new">'+trial.button_label+'</button>';

    display_element.innerHTML = html;
	
	var rt_first = null;
	display_element.querySelector('#jspsych-survey-new-response').addEventListener('input', function() {
		if (rt_first == null){
			let firstTime = (new Date()).getTime();
			rt_first = firstTime - startTime;
		}
		
	});
	
    display_element.querySelector('#jspsych-survey-new-next').addEventListener('click', function() {
      // measure response time
      var endTime = (new Date()).getTime();
      var response_time = endTime - startTime;
	  
	  var val = display_element.querySelector('#jspsych-survey-new-response').value;
	        
	  if (val.length == 0) {
		console.log('did not type enough');
		return;
	  }
	  /* OLD CODE, USED WHEN THERE WERE MULTIPLE POSSIBLE QUESTIONS
      // create object to hold responses
      var question_data = {};
      var matches = display_element.querySelectorAll('div.jspsych-survey-new-question');
      for(var index=0; index<matches.length; index++){
        var id = "Q" + index;
        var val = matches[index].querySelector('textarea, input').value;
        var obje = {};
        obje[id] = val;
        Object.assign(question_data, obje);
      }
	  */
      // save data
      var trialdata = {
        "rt": response_time,
		"rtfirst": rt_first,
        "response": val //originally had JSON.stringify here. Not sure it's needed?
      };

      

	  // next trial
	  if (val.length > 0 ){
		display_element.innerHTML = '';
		jsPsych.finishTrial(trialdata);
	  }
    });

    var startTime = (new Date()).getTime();
  };

  return plugin;
})();
